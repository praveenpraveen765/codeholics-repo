// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCb7JeiRfQvEcEQt_HRaGLhrt8G7b6DRcg",
  authDomain: "ai-agent-cab5c.firebaseapp.com",
  databaseURL: "https://ai-agent-cab5c-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "ai-agent-cab5c",
  storageBucket: "ai-agent-cab5c.firebasestorage.app",
  messagingSenderId: "96144763364",
  appId: "1:96144763364:web:8d76c38c854330301cfff1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);